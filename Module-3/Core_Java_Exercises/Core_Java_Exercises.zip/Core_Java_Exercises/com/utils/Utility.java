package com.utils;

public class Utility {
    public static String getMessage() {
        return "Hello from Utility module!";
    }
}
