package com.greetings;

import com.utils.Utility;

public class MainApp {
    public static void main(String[] args) {
        System.out.println(Utility.getMessage());
    }
}
